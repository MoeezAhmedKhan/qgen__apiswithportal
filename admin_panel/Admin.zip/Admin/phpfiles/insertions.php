<?php
// for the insertion of Main Categories
if(isset($_POST['btnSubmit_insertCategories'])){
include('../assets/connection.php');
  session_start();
  $cat_name = $_POST['Cat_name'];
  $userid = $_SESSION['userID'];
  
  $sql = "INSERT INTO `tbl_main_categories`(`category_name`, `category_creator`) VALUES ('$cat_name', $userid )";
  

  $result =  mysqli_query($con,$sql);
  if($result){
    header("Location:../insertCategories.php");
  }else{
    echo "<script>alert('There was an error occured!')</script>";
  }

}

// for the insertion of sub Categories
if(isset($_POST['btnSubmit_insertsubCategories']))
{
include('../assets/connection.php');
  session_start();
     $userid = $_SESSION['userID'];
     $subcat_name = $_POST['subCat_name'];
     $categoryId = $_POST['category'];
   
     

  $sql = "INSERT INTO `tbl_sub_categories`(`category_id`,`sub_category_name`,`sub_category_creator`) VALUES ($categoryId,'$subcat_name',$userid)";


if(mysqli_query($con,$sql))
  {

    header("Location:../Insertsubcategory.php");
  }
  else{
    echo "<script>alert('There was an error occured')</script>";
  }

}



//for the insertion of Mcq's
if (isset($_POST['EnterBatch'])) {
  include('../assets/connection.php');
  session_start();

  $BatchName = $_POST['BatchName'];
  $Email = $_POST['Email'];
  $Password = $_POST['Password'];
  $Zakat = $_POST['Zakat'];
  $Sadqa = $_POST['Sadqa'];
  

  $check = "SELECT * FROM `tbl_users` WHERE `user_email` = '$Email' OR `user_name` = '$BatchName'";
  $check_execute = mysqli_query($con,$check);

  if(mysqli_fetch_array($check_execute) == 0){
     $sql = "INSERT INTO `tbl_users`(`user_email`, `user_name`, `user_password`
      , `Zakat`, `Sadqa`) VALUES ('$Email', '$BatchName' , '$Password' , '$Zakat' , '$Sadqa')";

      $result = mysqli_query($con,$sql);
      if($result){
         header("Location: ../addmsqs.php?Massage=Sucessfull added new batch.");
      }
    }else{
       header("Location: ../addmsqs.php?Massage=Could not add as migth be batch or email already exist!");
    }

}
  
if(isset($_GET['CreateQuiz'])){
  session_start();  
  include('../assets/connection.php');
  header("Content-Type: text/plain");
  $quiz_tittle = $_GET['quiz_tittle'];
  $quiz_total_marks = $_GET['quiz_total_marks'];
  $categories = $_GET['quiz_categories'];
  $categories_size = sizeof($categories);
  $creator_id = $_SESSION['userID'];
  
  $create_quiz_sql = "INSERT INTO `tbl_quiz`(`quiz_tittle`,`quiz_creator`, `quiz_total_marks`) VALUES ('$quiz_tittle',$creator_id,$quiz_total_marks)";
      $insert = mysqli_query($con,$create_quiz_sql);
 
       $last_id = $con->insert_id;
       foreach ($categories as $cat_id){
         $sql = "SELECT `mcqs_id`, `sub_category_id`, `mcqs_question_type`, `mcqs_question`, `mcqs_options_type`, `mcqs_option_1`, `mcqs_option_2`, `mcqs_option_3`, `mcqs_option_4`, `mcqs_answer`, `mcqs_creator`, `mcqs_created_date` FROM `tbl_mcqs` WHERE `sub_category_id` = $cat_id ORDER BY rand() LIMIT 5";
         $execute = mysqli_query($con,$sql);
         while($row = mysqli_fetch_array($execute)){
             $mcqs_id = $row['mcqs_id'];
             $insert_questions = "INSERT INTO `tbl_quiz_questions`(`quiz_id`, `mcqs_id`) VALUES ($last_id,$mcqs_id)";
             $insert_questions;
             $inserted_questions = mysqli_query($con,$insert_questions);
             if($inserted_questions){
                 header("Location: ../createquiz.php?Massage=Sucessfull quiz added.");
             }
             
         }
      }

  
}  

if (isset($_POST['AddNewUser'])) {
  include('../assets/connection.php');
  session_start();
  $username = $_POST['username'];
  $usertype = $_POST['usertype'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $passwrod = $_POST['passwrod'];

  $check_email = "SELECT * FROM `tbl_users` WHERE `user_name` = '$username' OR `user_email` = '$email'";
  $result_check = mysqli_query($con,$check_email);
  if(mysqli_num_rows($result_check) == 0){

    $sql = "INSERT INTO `tbl_users`(`user_name`, `user_email`, `user_phone`, `user_password`,  `user_type`) VALUES ('$username' , '$email' , '$phone' , '$passwrod' , '$usertype')";
    $result = mysqli_query($con,$sql);
    if($result){
        header("Location: ../addnewusers.php?Massage=Sucessfull added new user.");
    }
  }else{
    header("Location: ../addnewusers.php?Massage=The email address or username already exist!");
  }


}


?>