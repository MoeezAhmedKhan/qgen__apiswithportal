<?php


if($_POST['request_name']== 'authentication'){
    include("../connection.php");
    $username = $_POST['email'];
    $passowrd = $_POST['password'];

    $sql = "SELECT `user_id`, `user_name`, `profilepic`, `user_email`, `user_phone`, `user_password`, `user_status`, `user_type`, `user_created_date` FROM `tbl_users` WHERE `user_name`= '$username' AND `user_password` = '$passowrd' OR `user_email` = '$username' AND `user_password` ='$passowrd'";
    
    $execute = mysqli_query($con,$sql);
    if(mysqli_num_rows($execute)>0){
        $Data  = mysqli_fetch_array($execute);
        $data = array("User_type"=>$Data['user_type'],
                          "User_id"=>$Data['user_id'],
                          "user_name"=>$Data['user_name'],
                          "profilepic"=>$Data['profilepic'],
                          "user_email"=>$Data['user_email'],
                          "user_phone"=>$Data['user_phone']
                          );
                          
        $response = array("Response"=>200,
                          "Message"=>"Fetched Data.",
                          "isAuthenticated"=>true,
                          "User_Details"=>$data
                          );    
        echo json_encode($response); 
    }else{
        
         $data = array("User_type"=>null,
                          "User_id"=>null,
                          "user_name"=>null,
                          "profilepic"=>null,
                          "user_email"=>null,
                          "user_phone"=>null,
                          );
                          
        $response = array("Response"=>400,
                          "Message"=>"Invalid username or password.",
                          "isAuthenticated"=>false,
                          "User_Details"=>$data
                          );    
        echo json_encode($response); 
        
    }
    
    
}else if($_POST['request_name']== 'fetchmcqs'){
    
    include("../connection.php");
    $sub_cat_id = $_POST['Sub_Category_Id'];
    $user_id = $_POST['user_id'];
    $page_id = $_POST['page_id'];
    $fetch_data = "SELECT `mcqs_id`, `sub_category_id`, `mcqs_question_type`, tbl_users.user_name ,`mcqs_question`, `mcqs_options_type`, `mcqs_option_1`, `mcqs_option_2`, `mcqs_option_3`, `mcqs_option_4`, `mcqs_answer`, `mcqs_creator`, `mcqs_created_date` FROM `tbl_mcqs` INNER JOIN tbl_users On tbl_users.user_id = tbl_mcqs.mcqs_creator WHERE `sub_category_id` =  $sub_cat_id";
    
    $execute = mysqli_query($con,$fetch_data);
    $total_mcqs = mysqli_num_rows($execute);
     $decimal =  $total_mcqs/10;
    $intpart = floor( $decimal );  
    $fraction = $decimal - $intpart; 
    $total_pages = 1;
    if($fraction == 0){
          $total_pages = $intpart;
    }else{
          $total_pages = $intpart + 1;
    }
    
    if($total_mcqs > 0){
        $data_msqs  = array();
        $index = 0;    
        while($row_mcqs = mysqli_fetch_array($execute)){
           $index++;
           if($index > (($page_id-1)*10)){
           $mcqs_id   =  $row_mcqs['mcqs_id'];
           $creator = $row_mcqs['mcqs_creator'];
           $sql_comment = "SELECT COUNT(mcqs_id) as count_comment FROM mcsq_comments Where `mcqs_id` = $mcqs_id";
           $execute_comment = mysqli_query($con,$sql_comment);
           $Data = mysqli_fetch_array($execute_comment); 
           $count_comments = $Data['count_comment'];
           
           $sql_likes = "SELECT COUNT(mcqs_id) as COUNT_Likes FROM `tbl_mcqs_like`  Where `mcqs_id` = $mcqs_id";
           $execute_likes = mysqli_query($con,$sql_likes);
           $Data = mysqli_fetch_array($execute_likes); 
           $count_likes = $Data['COUNT_Likes'];
           
           $liked = false;
           
           $sql_liked = "SELECT mcqs_id as COUNT_Likes FROM `tbl_mcqs_like`  Where `mcqs_id` = $mcqs_id AND `user_id` = $user_id";
           $execute_liked = mysqli_query($con,$sql_liked);
           if(mysqli_num_rows($execute_liked) > 0){
               $liked = true;
           }
           
           $reported = false;
           
           $sql_report = "SELECT * FROM `tbl_report_mcqs` WHERE `reported_by` = $user_id AND `mcqs_id` = $mcqs_id ";
           $execute_reported = mysqli_query($con,$sql_report);
           if(mysqli_num_rows($execute_reported) > 0){
               $reported = true;
           }
            $badges = array();
            $sql_count = "SELECT COUNT(*) as followed FROM `tbl_follower` WHERE `user_id` =  $creator";
            $execute_followed_count = mysqli_query($con,$sql_count);
            $Data_Followed = mysqli_fetch_array($execute_followed_count);
            $count_followers = $Data_Followed['followed'];
               if($count_followers >= 0){
                   $temp = ['icon'=>"badges/badge-icon-verified.png",'reason'=>"This user has more than 1000 followers."];
                   array_push($badges,$temp);
               }
    
            $sql_count_mcqs = "SELECT Count(*) as count_mcqs FROM `tbl_mcqs` WHERE `mcqs_creator`   =  $creator";
            $execute_count_mcqs = mysqli_query($con,$sql_count_mcqs);
            $Data_Mcqs = mysqli_fetch_array($execute_count_mcqs);
             $count_mcqs = $Data_Mcqs['count_mcqs'];
             if($count_mcqs >= 0){
                  $temp = ['icon'=>"badges/badge-icon-mcqs.png",'reason'=>"This user has posted more than 1000 mcqs."];
                   array_push($badges,$temp);
                  
               }
           
           $data = ["mcqs_id"=>$row_mcqs['mcqs_id'],
                    "mcqs_question_type"=>$row_mcqs['mcqs_question_type'],
                    "mcqs_question"=>$row_mcqs['mcqs_question'],
                    "mcqs_options_type"=>$row_mcqs['mcqs_options_type'],
                    "mcqs_option_1"=>$row_mcqs['mcqs_option_1'],
                    "mcqs_option_2"=>$row_mcqs['mcqs_option_2'],
                    "mcqs_option_3"=>$row_mcqs['mcqs_option_3'],
                    "mcqs_option_4"=>$row_mcqs['mcqs_option_4'],
                    "mcqs_option_4"=>$row_mcqs['mcqs_option_4'],
                    "user_id"=>$row_mcqs['mcqs_creator'],
                    "user_name"=>$row_mcqs['user_name'],
                    "Likes_count"=>$count_likes,
                    "badges"=>$badges,
                    "Comments_count"=>$count_comments,
                    "Liked"=>$liked,
                    "Reported"=>$reported
                    ];
                    
                   
           array_push($data_msqs,$data);
          }
           
        }
        $response = array("Response"=>200,
                          "Message"=>"Fetched Mcqs.",
                          "Total_pages"=>$total_pages,
                          "Data"=>$data_msqs
                          );    
         echo json_encode($response); 
    }else{
        $response = array("Response"=>204,
                          "Total_pages"=>$total_pages,
                          "Message"=>"This Category has not mcqs.",
                          "Data"=>"No Data"
                          );    
         echo json_encode($response); 
    }
    
}else if($_POST['request_name']== 'fetchComment'){
    
    include("../connection.php");
    $mcqs_id = $_POST['mcqs_id'];
    $fetch_data = "SELECT `comment_id`, tbl_users.user_id , tbl_users.user_name , `mcqs_id`, `comment`, `created_date` FROM `mcsq_comments` INNER JOIN tbl_users ON tbl_users.user_id = mcsq_comments.user_id WHERE `mcqs_id`= $mcqs_id";
    $execute = mysqli_query($con,$fetch_data);
    if(mysqli_num_rows($execute) > 0){
        $data_comments  = array();
        while($row_comments = mysqli_fetch_array($execute)){
            
           $mcqs_id   =  $row_mcqs['mcqs_id'];
           
           
           $data = [
                    "comment_id"=>$row_comments['comment_id'],
                    "user_id"=>$row_comments['user_id'],
                    "user_name"=>$row_comments['user_name'],
                    "comment"=>$row_comments['comment'],
                    "created_date"=>$row_comments['created_date']
                    ];
                    
                   
           array_push($data_comments,$data);
           
        }
        $response = array("Response"=>200,
                          "Message"=>"Fetched Mcqs.",
                          "Data"=>$data_comments
                          );    
         echo json_encode($response); 
    }else{
        $response = array("Response"=>204,
                          "Message"=>"This Category has not mcqs.",
                          "Data"=>"No Data"
                          );    
         echo json_encode($response); 
    }
    
}else if($_POST['request_name']== 'fetchQuizList'){
    
    include("../connection.php");
    $fetch_data = "SELECT `quiz_id`, `quiz_tittle`, tbl_users.user_name , `quiz_created_date`, `quiz_creator`, `quiz_status`, `quiz_total_marks` FROM `tbl_quiz` INNER JOIN tbl_users ON tbl_users.user_id = tbl_quiz.quiz_creator";
    $execute = mysqli_query($con,$fetch_data);
    if(mysqli_num_rows($execute) > 0){
        $data_comments  = array();
        while($row_comments = mysqli_fetch_array($execute)){
            
           $mcqs_id   =  $row_mcqs['mcqs_id'];
           
           
           $data = [
                    "quiz_id"=>$row_comments['quiz_id'],
                    "quiz_tittle"=>$row_comments['quiz_tittle'],
                    "quiz_created_date"=>$row_comments['quiz_created_date'],
                    "quiz_creator"=>$row_comments['user_name'],
                    "quiz_creator_id"=>$row_comments['quiz_creator'],
                    "quiz_total_marks"=>$row_comments['quiz_total_marks'],
                    ];
                    
                   
           array_push($data_comments,$data);
           
        }
        $response = array("Response"=>200,
                          "Message"=>"Fetched Mcqs.",
                          "Data"=>$data_comments
                          );    
         echo json_encode($response); 
    }else{
        $response = array("Response"=>204,
                          "Message"=>"This Category has not mcqs.",
                          "Data"=>"No Data"
                          );    
         echo json_encode($response); 
    }
    
}else if($_POST['request_name']== 'fetchResult'){
    
    include("../connection.php");
    $user_id = $_POST['user_id'];
   $sql_get_result = "SELECT * FROM `tbl_quiz` INNER JOIN tbl_quiz_answer ON tbl_quiz_answer.quiz_id = tbl_quiz.quiz_id WHERE tbl_quiz_answer.user_id = $user_id GROUP BY tbl_quiz.quiz_id";
    $execute = mysqli_query($con,$sql_get_result);
    $data = array();
   
    while($row = mysqli_fetch_array($execute)){
        $quiz_id = $row['quiz_id'];
        $total_marks = $row['quiz_total_marks'];
        $sql = "SELECT * FROM `tbl_quiz_answer` INNER JOIN tbl_mcqs On tbl_mcqs.mcqs_id = tbl_quiz_answer.mcqs_id WHERE `quiz_id` =  $quiz_id";
        $execute_answer = mysqli_query($con,$sql);
        $correct_answers = 0;
        $totalquestions = 0;
        while($rowanswer = mysqli_fetch_array($execute_answer)){
             if($rowanswer['answer_option'] == $rowanswer['mcqs_answer']){
                 $correct_answers++;
             }
             $totalquestions++;
        }
        $each_mark = ($row['quiz_total_marks']/$totalquestions);
        $gain_marks = $each_mark * $correct_answers;
        $temp = ["quiz_tittle"=>$row['quiz_tittle'],
                 "quiz_id"=>$row['quiz_id'],    
                 "Total_questions"=>$totalquestions,    
                 "Correct_answers"=>$correct_answers,    
                 "Total_marks"=>$row['quiz_total_marks'],    
                 "Obtain_marks"=>$gain_marks,    
                 ];
        array_push($data,$temp);
    }
     $response = array("Response"=>200,
                          "Message"=>"Fetched Quiz Results.",
                          "Data"=>$data
                          );    
     echo json_encode($response); 
    
}else if($_POST['request_name']== 'fetchQuizbyid'){
    
    include("../connection.php");
    $quiz_id = $_POST['quiz_id'];
    $fetch_data = "SELECT `question_id`, `quiz_id`, tbl_mcqs.mcqs_id , tbl_mcqs.mcqs_question, tbl_mcqs.mcqs_question_type , tbl_mcqs.mcqs_options_type , tbl_mcqs.mcqs_option_1 , tbl_mcqs.mcqs_option_2 , tbl_mcqs.mcqs_option_3 , tbl_mcqs.mcqs_option_4 , tbl_mcqs.mcqs_answer FROM `tbl_quiz_questions` INNER JOIN tbl_mcqs on tbl_mcqs.mcqs_id = tbl_quiz_questions.mcqs_id WHERE `quiz_id` = $quiz_id";
    $execute = mysqli_query($con,$fetch_data);
    if(mysqli_num_rows($execute) > 0){
        $data_comments  = array();
        while($row_comments = mysqli_fetch_array($execute)){
            
           $mcqs_id   =  $row_mcqs['mcqs_id'];
           
           
              $data = [
                    "question_id"=>$row_comments['question_id'],
                    "quiz_id"=>$row_comments['quiz_id'],
                    "mcqs_id"=>$row_comments['mcqs_id'],
                    "quiz_question_type"=>$row_comments['mcqs_question_type'],
                    "quiz_question"=>$row_comments['mcqs_question'],
                    "quiz_options_type"=>$row_comments['mcqs_options_type'],
                    "quiz_option_1"=>$row_comments['mcqs_option_1'],
                    "quiz_option_2"=>$row_comments['mcqs_option_2'],
                    "quiz_option_3"=>$row_comments['mcqs_option_3'],
                    "quiz_option_4"=>$row_comments['mcqs_option_4'],
                    "quiz_answer"=>$row_comments['mcqs_answer'],
                    "selected_option"=>null,
                    ];
                    
            
           array_push($data_comments,$data);
           
        }
        $response = array("Response"=>200,
                          "Message"=>"Fetched Mcqs.",
                          "Data"=>$data_comments
                          );    
         echo json_encode($response); 
    }else{
        $response = array("Response"=>202,
                          "Message"=>"This Quiz has no questions.",
                          "Data"=>"No Data"
                          );    
         echo json_encode($response); 
    }
    
}else if($_POST['request_name']== 'fetchCategories'){
    
    include("../connection.php");
    $fetch_main_categories = "SELECT `category_id`, `category_name`, `category_creator`, `category_created_date` FROM `tbl_main_categories`";
    $execute = mysqli_query($con,$fetch_main_categories);
    if(mysqli_num_rows($execute) > 0){
        $data_sub  = array();
        while($row_categories = mysqli_fetch_array($execute)){
            $category_id = $row_categories['category_id'];
             $category_name = $row_categories['category_name'];
            $fetch_sub_categories = "SELECT `sub_category_id`, `category_id`, `sub_category_name`, `category_icon`, `sub_category_creator`, `sub_category_created_date` FROM `tbl_sub_categories` WHERE `category_id` = $category_id";
            $execute_sub_categories = mysqli_query($con,$fetch_sub_categories);
            if(mysqli_num_rows($execute_sub_categories) > 0){
                 $data_sub_cat = array();
                 while($row_sub_categories = mysqli_fetch_array   ($execute_sub_categories)){
                   $temp = [
                                "sub_category_id"=>$row_sub_categories['sub_category_id'],
                                "category_id"=>$category_id,
                                "sub_category_name"=>$row_sub_categories['sub_category_name'],"sub_category_icon"=>"https://worldmcqs.org/Admin/".$row_sub_categories['category_icon'],
                             ];
                   
                    array_push($data_sub_cat,$temp);         
                  }
                   $temp_main  = ["Category_Name"=>$category_name,
                                      "Sub_Cat"=>$data_sub_cat,
                                      "category_id"=>$category_id];
                   array_push($data_sub,$temp_main);
            }
              
           
        }
    }
    $response = array("Response"=>200,
                          "Message"=>"Fetched Data.",
                          "Data"=>$data_sub
                          );    
    echo json_encode($response); 
    
    
    
    
}else if($_POST['request_name']== 'fetchProfile'){
    
    include("../connection.php");
    $user_id = $_POST['user_id'];
    $my_id = $_POST['my_id'];
    $fetch_profile = "SELECT `user_id`, `user_name`, `profilepic`, `user_email`, `user_phone`, `user_password`, `user_status`, `user_type`, `user_created_date` FROM `tbl_users` WHERE `user_id` = $user_id";
    $execute_profile = mysqli_query($con,$fetch_profile);
    $followed = false;
    $reported = false;
    
    $sql_followed = "SELECT * FROM `tbl_follower` WHERE `user_id` =  $user_id AND `follower_id` =  $my_id";
    $execute_followed = mysqli_query($con,$sql_followed);
    if(mysqli_num_rows($execute_followed) > 0){
        $followed = true;
    }
    
    $sql_reported = "SELECT `report_id`, `reported_by`, `reported_id`, `reason` FROM `tbl_report` WHERE `reported_by`  =  $my_id";
    $execute_reported = mysqli_query($con,$sql_reported);
    if(mysqli_num_rows($execute_reported) > 0){
        $reported = true;
    }
    
    $sql_count = "SELECT COUNT(*) as followed FROM `tbl_follower` WHERE `user_id` =  $user_id";
    $execute_followed_count = mysqli_query($con,$sql_count);
    $Data_Followed = mysqli_fetch_array($execute_followed_count);
    $count_followers = $Data_Followed['followed'];
    $badges = array();
    if($count_followers >= 0){
                   $temp = ['icon'=>"badges/badge-icon-verified.png",'reason'=>"This user has more than 1000 followers."];
                   array_push($badges,$temp);
               }
    
    
    $sql_count_mcqs = "SELECT Count(*) as count_mcqs FROM `tbl_mcqs` WHERE `mcqs_creator`   =  $user_id";
    $execute_count_mcqs = mysqli_query($con,$sql_count_mcqs);
    $Data_Mcqs = mysqli_fetch_array($execute_count_mcqs);
    $count_mcqs = $Data_Mcqs['count_mcqs'];
     if($count_mcqs >= 0){
                  $temp = ['icon'=>"badges/badge-icon-mcqs.png",'reason'=>"This user has posted more than 1000 mcqs."];
                   array_push($badges,$temp);
                  
               }
               
               
    $sql_get_result = "SELECT * FROM `tbl_quiz` INNER JOIN tbl_quiz_answer ON tbl_quiz_answer.quiz_id = tbl_quiz.quiz_id WHERE tbl_quiz_answer.user_id = $user_id GROUP BY tbl_quiz.quiz_id";
    $execute = mysqli_query($con,$sql_get_result);
    $data = array();
    $totalMarks = null;
    $gain_marks =null;
    while($row = mysqli_fetch_array($execute)){
        $quiz_id = $row['quiz_id'];
        $total_marks = $row['quiz_total_marks'];
        $sql = "SELECT * FROM `tbl_quiz_answer` INNER JOIN tbl_mcqs On tbl_mcqs.mcqs_id = tbl_quiz_answer.mcqs_id WHERE `quiz_id` =  $quiz_id";
        $execute_answer = mysqli_query($con,$sql);
        $correct_answers = 0;
        $totalquestions = 0;
        while($rowanswer = mysqli_fetch_array($execute_answer)){
             if($rowanswer['answer_option'] == $rowanswer['mcqs_answer']){
                 $correct_answers++;
             }
             $totalquestions++;
        }
        $each_mark  = ($row['quiz_total_marks']/$totalquestions);
        $gain_marks += $each_mark * $correct_answers;         
        $totalMarks +=  $row['quiz_total_marks'];  
    } 
    
    if($totalMarks == $gain_marks){
         $temp = ['icon'=>"badges/100_perent_answers.jpg",'reason'=>"This user has obtained 100% marks in quizes."];
                   array_push($badges,$temp);
    }
    
    if(mysqli_num_rows($execute_profile) > 0){
       $Data = mysqli_fetch_array($execute_profile); 
        $data = array(
                  "user_name"=>$Data['user_name'],
                  "badges"=>$badges,
                  "profilepic"=>$Data['profilepic'],
                  "user_email"=>$Data['user_email'],
                  "user_phone"=>$Data['user_phone'],
                  "user_status"=>$Data['user_status'],
                  "user_type"=>$Data['user_type'],
                  "followed"=>$followed,
                  "reported"=>$reported,
                  "followers"=>$count_followers,
                  "total_mcqs"=>$count_mcqs,
                  
                );
      
       $response = array("Response"=>200,
                          "Message"=>"Fetched Data.",
                          "Data"=>$data
                          );    
       echo json_encode($response); 
    }else{
        $data = array(
                  "user_name"=>null,
                  "profilepic"=>null,
                  "user_email"=>null,
                  "user_phone"=>null,
                  "user_status"=>null,
                  "user_type"=>null,
                  "followed"=>null,
                  
                );
        $response = array("Response"=>204,
                          "Message"=>"There is no such user.",
                          "Data"=>$data
                          );    
       echo json_encode($response);
    }
   
    
    
}else{
   $response = array("Response"=>"404","Message"=>"Invalid Prams");
   echo json_encode($response);
}




?>