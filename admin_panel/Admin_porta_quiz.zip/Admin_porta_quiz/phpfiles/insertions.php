<?php
// for the insertion of Main Categories
if(isset($_POST['btnSubmit_insertCategories'])){
include('../assets/connection.php');
  session_start();
  $cat_name = $_POST['Cat_name'];
  $userid = $_SESSION['userID'];
  
  $sql = "INSERT INTO `tbl_main_categories`(`category_name`, `category_creator`) VALUES ('$cat_name', $userid )";
  

  $result =  mysqli_query($con,$sql);
  if($result){
    header("Location:../insertCategories.php");
  }else{
    echo "<script>alert('There was an error occured!')</script>";
  }

}

// for the insertion of sub Categories
if(isset($_POST['btnSubmit_insertsubCategories']))
{
include('../assets/connection.php');
  session_start();
     $userid = $_SESSION['userID'];
     $subcat_name = $_POST['subCat_name'];
     $categoryId = $_POST['category'];
   
     

  $sql = "INSERT INTO `tbl_sub_categories`(`category_id`,`sub_category_name`,`sub_category_creator`) VALUES ($categoryId,'$subcat_name',$userid)";


if(mysqli_query($con,$sql))
  {

    header("Location:../Insertsubcategory.php");
  }
  else{
    echo "<script>alert('There was an error occured')</script>";
  }

}



//for the insertion of Mcq's
if (isset($_POST['EnterMcqs'])) {
  include('../assets/connection.php');
  session_start();

  $mcqsQuesType = $_POST['mcqsQuesType'];
  $userid = $_SESSION['userID'];
  $subcatId = $_POST['subcatId'];
  $mcqsOptionType = $_POST['mcqsOptionType'];
  $mcqsAnswer = $_POST['mcqsAnswer'];
 

  if($mcqsQuesType == 'image'){
    if(isset($_FILES['mcqsQuesImg']['name'])){
      $errors= array();
      $file_name = $_FILES['mcqsQuesImg']['name'];
      $file_size =$_FILES['mcqsQuesImg']['size'];
      $file_tmp =$_FILES['mcqsQuesImg']['tmp_name'];
      $file_type=$_FILES['mcqsQuesImg']['type'];
      $tmp_question = explode('.', $file_name);
      $file_ext = end($tmp_question);
      
      


      
      $extensions= array("jpeg","jpg","png","JPEG","JPG","PNG");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
         echo 'Size of Question image is big!';
      }
      $imageNewName = date("Ymdhis").rand(10,100)."Question";
     
      if(empty($errors)==true){       
          move_uploaded_file($file_tmp,"../Uploads/".$imageNewName.".".$file_ext);
             $imageURL_question = $imageNewName.".".$file_ext;
        
          $sql = "INSERT INTO `tbl_mcqs`(`sub_category_id`, `mcqs_question_type`, `mcqs_question`, `mcqs_options_type`, `mcqs_answer`, `mcqs_creator`) VALUES ($subcatId,'$mcqsQuesType','$imageURL_question','$mcqsOptionType',$mcqsAnswer,$userid)";
          $result = mysqli_query($con,$sql);
          $last_id = $con->insert_id;


          if($result){

            if($mcqsOptionType == 'image'){



                $file_name_o1 = $_FILES['imgOption1']['name'];
                $file_size_o1 =$_FILES['imgOption1']['size'];
                $file_tmp_o1 =$_FILES['imgOption1']['tmp_name'];
                $file_type_o1=$_FILES['imgOption1']['type'];
                $tmp_o1 = explode('.', $file_name_o1);
                $file_ext_o1 = end($tmp_o1);

                $file_name_o2 = $_FILES['imgOption2']['name'];
                $file_size_o2 =$_FILES['imgOption2']['size'];
                $file_tmp_o2 =$_FILES['imgOption2']['tmp_name'];
                $file_type_o2=$_FILES['imgOption2']['type'];
                $tmp_o2 = explode('.', $file_name_o2);
                $file_ext_o2 = end($tmp_o2);

                $file_name_o3 = $_FILES['imgOption3']['name'];
                $file_size_o3 =$_FILES['imgOption3']['size'];
                $file_tmp_o3 =$_FILES['imgOption3']['tmp_name'];
                $file_type_o3=$_FILES['imgOption3']['type'];
                $tmp_o3 = explode('.', $file_name_o3);
                $file_ext_o3 = end($tmp_o3);


                $file_name_o4 = $_FILES['imgOption4']['name'];
                $file_size_o4 =$_FILES['imgOption4']['size'];
                $file_tmp_o4 =$_FILES['imgOption4']['tmp_name'];
                $file_type_o4=$_FILES['imgOption4']['type'];
                $tmp_o4 = explode('.', $file_name_o4);
                $file_ext_o4 = end($tmp_o4);

                if(in_array($file_ext_o1,$extensions)=== false ||  in_array($file_ext_o2,$extensions)=== false ||  in_array($file_ext_o3,$extensions)=== false  ||  in_array($file_ext_o4,$extensions)=== false){
                   $errors[]="extension not allowed, please choose a JPEG or PNG file.";
                }

                if($file_size_o1 > 2097152  || $file_size_o2 > 2097152 || $file_size_o3 > 2097152 || $file_size_o4 > 2097152){
                   $errors[]='File size must be excately 2 MB';
                }
                  $imageNewName_o1 = date("Ymdhis").rand(10,100)."Option1";
                  $imageNewName_o2 = date("Ymdhis").rand(10,100)."Option2";
                  $imageNewName_o3 = date("Ymdhis").rand(10,100)."Option3";
                  $imageNewName_o4 = date("Ymdhis").rand(10,100)."Option4";
                if(empty($errors)==true){
                  move_uploaded_file($file_tmp_o1,"../Uploads/".$imageNewName_o1.".".$file_ext_o1);
                  move_uploaded_file($file_tmp_o2,"../Uploads/".$imageNewName_o2.".".$file_ext_o2);
                  move_uploaded_file($file_tmp_o3,"../Uploads/".$imageNewName_o3.".".$file_ext_o3);
                  move_uploaded_file($file_tmp_o4,"../Uploads/".$imageNewName_o4.".".$file_ext_o3);

                  $img_o1 = $imageNewName_o1.".".$file_ext_o1;
                  $img_o2 = $imageNewName_o2.".".$file_ext_o2;
                  $img_o3 = $imageNewName_o3.".".$file_ext_o3;
                  $img_o4 = $imageNewName_o4.".".$file_ext_o4;

                  $sqUpdateOptn = "UPDATE `tbl_mcqs` SET `mcqs_option_1` = '$img_o1' , `mcqs_option_2` = '$img_o2', `mcqs_option_3` = '$img_o3' , `mcqs_option_4` = '$img_o4' WHERE `mcqs_id` = $last_id";
                  $result_optn = mysqli_query($con,$sqUpdateOptn);
                  if($result_optn){
                      header("Location: ../addmsqs.php?Massage=Sucessfully added");
                  }
                }

            }else{
                  $textOption1  =  $_POST['textOption1'];
                  $textOption2  =  $_POST['textOption2'];
                  $textOption3  =  $_POST['textOption3'];
                  $textOption4  =  $_POST['textOption4'];
               
                  $sqUpdateOptn = "UPDATE `tbl_mcqs` SET `mcqs_option_1` = '$textOption1' , `mcqs_option_2` = '$textOption2', `mcqs_option_3` = '$textOption3' , `mcqs_option_4` = '$textOption4' WHERE `mcqs_id` = $last_id";
                  $result_optn = mysqli_query($con,$sqUpdateOptn);
                  if($result_optn){
                      header("Location: ../addmsqs.php?Massage=Sucessfully added");
                  }
            }
            
         
          }
       }
          
      }else{
         print_r($errors);
      }
  }
  else{
    $mcqsQuesText  =  $_POST['mcqsQuesText'];
     $sql = "INSERT INTO `tbl_mcqs`(`sub_category_id`, `mcqs_question_type`, `mcqs_question`, `mcqs_options_type`, `mcqs_answer`, `mcqs_creator`) VALUES ($subcatId,'$mcqsQuesType','$mcqsQuesText','$mcqsOptionType',$mcqsAnswer,$userid)";
     $result = mysqli_query($con,$sql);
      $last_id = $con->insert_id;
          if($result){
            if($mcqsOptionType == 'image'){



                $file_name_o1 = $_FILES['imgOption1']['name'];
                $file_size_o1 =$_FILES['imgOption1']['size'];
                $file_tmp_o1 =$_FILES['imgOption1']['tmp_name'];
                $file_type_o1=$_FILES['imgOption1']['type'];
                $tmp_o1 = explode('.', $file_name_o1);
                $file_ext_o1 = end($tmp_o1);

                $file_name_o2 = $_FILES['imgOption2']['name'];
                $file_size_o2 =$_FILES['imgOption2']['size'];
                $file_tmp_o2 =$_FILES['imgOption2']['tmp_name'];
                $file_type_o2=$_FILES['imgOption2']['type'];
                $tmp_o2 = explode('.', $file_name_o2);
                $file_ext_o2 = end($tmp_o2);

                $file_name_o3 = $_FILES['imgOption3']['name'];
                $file_size_o3 =$_FILES['imgOption3']['size'];
                $file_tmp_o3 =$_FILES['imgOption3']['tmp_name'];
                $file_type_o3=$_FILES['imgOption3']['type'];
                $tmp_o3 = explode('.', $file_name_o3);
                $file_ext_o3 = end($tmp_o3);


                $file_name_o4 = $_FILES['imgOption4']['name'];
                $file_size_o4 =$_FILES['imgOption4']['size'];
                $file_tmp_o4 =$_FILES['imgOption4']['tmp_name'];
                $file_type_o4=$_FILES['imgOption4']['type'];
                $tmp_o4 = explode('.', $file_name_o4);
                $file_ext_o4 = end($tmp_o4);

                if(in_array($file_ext_o1,$extensions)=== false ||  in_array($file_ext_o2,$extensions)=== false ||  in_array($file_ext_o3,$extensions)=== false  ||  in_array($file_ext_o4,$extensions)=== false){
                   $errors[]="extension not allowed, please choose a JPEG or PNG file.";
                }

                if($file_size_o1 > 2097152  || $file_size_o2 > 2097152 || $file_size_o3 > 2097152 || $file_size_o4 > 2097152){
                   $errors[]='File size must be excately 2 MB';
                }
                  $imageNewName_o1 = date("Ymdhis").rand(10,100)."Option1";
                  $imageNewName_o2 = date("Ymdhis").rand(10,100)."Option2";
                  $imageNewName_o3 = date("Ymdhis").rand(10,100)."Option3";
                  $imageNewName_o4 = date("Ymdhis").rand(10,100)."Option4";
                if(empty($errors)==true){
                  move_uploaded_file($file_tmp_o1,"../Uploads/".$imageNewName_o1.$file_ext_o1);
                  move_uploaded_file($file_tmp_o2,"../Uploads/".$imageNewName_o2.$file_ext_o2);
                  move_uploaded_file($file_tmp_o3,"../Uploads/".$imageNewName_o3.$file_ext_o3);
                  move_uploaded_file($file_tmp_o4,"../Uploads/".$imageNewName_o4.$file_ext_o3);

                  $img_o1 = $imageNewName_o1.".".$file_ext_o1;
                  $img_o2 = $imageNewName_o2.".".$file_ext_o2;
                  $img_o3 = $imageNewName_o3.".".$file_ext_o3;
                  $img_o4 = $imageNewName_o4.".".$file_ext_o4;

                  $sqUpdateOptn = "UPDATE `tbl_mcqs` SET `mcqs_option_1` = '$img_o1' , `mcqs_option_2` = '$img_o2', `mcqs_option_3` = '$img_o3' , `mcqs_option_4` = '$img_o4' WHERE `mcqs_id` = $last_id";
                  $result_optn = mysqli_query($con,$sqUpdateOptn);
                  if($result_optn){
                      header("Location: ../addmsqs.php?Massage=Sucessfully added");
                  }
                }

            }else{
                  $textOption1  =  $_POST['textOption1'];
                  $textOption2  =  $_POST['textOption2'];
                  $textOption3  =  $_POST['textOption3'];
                  $textOption4  =  $_POST['textOption4'];
                  $sqUpdateOptn = "UPDATE `tbl_mcqs` SET `mcqs_option_1` = '$textOption1' , `mcqs_option_2` = '$textOption2', `mcqs_option_3` = '$textOption3' , `mcqs_option_4` = '$textOption4' WHERE `mcqs_id` = $last_id)";
                  $result_optn = mysqli_query($con,$sqUpdateOptn);
                  if($result_optn){
                      header("Location: ../addmsqs.php?Massage=Sucessfully added");
                  }
            }
            
         
          }
  }

 

  }

if (isset($_POST['AddNewUser'])) {
  include('../assets/connection.php');
  session_start();
  $username = $_POST['username'];
  $usertype = $_POST['usertype'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $passwrod = $_POST['passwrod'];

  $check_email = "SELECT * FROM `tbl_users` WHERE `user_name` = '$username' OR `user_email` = '$email'";
  $result_check = mysqli_query($con,$check_email);
  if(mysqli_num_rows($result_check) == 0){

    $sql = "INSERT INTO `tbl_users`(`user_name`, `user_email`, `user_phone`, `user_password`,  `user_type`) VALUES ('$username' , '$email' , '$phone' , '$passwrod' , '$usertype')";
    $result = mysqli_query($con,$sql);
    if($result){
        header("Location: ../addnewusers.php?Massage=Sucessfull added new user.");
    }
  }else{
    header("Location: ../addnewusers.php?Massage=The email address or username already exist!");
  }


}


?>