<?php


require('../Library/php-excel-reader/excel_reader2.php');
require('../Library/SpreadsheetReader.php');
include_once('../assets/connection.php');


if(isset($_POST['btn_importExcel'])){

  $mimes = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.oasis.opendocument.spreadsheet', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  if(in_array($_FILES["file"]["type"],$mimes)){


    $uploadFilePath = '../excelFiles/'.basename($_FILES['file']['name']);
    move_uploaded_file($_FILES['file']['tmp_name'], $uploadFilePath);


    $Reader = new SpreadsheetReader($uploadFilePath);


    $totalSheet = count($Reader->sheets());


    


    /* For Loop for all sheets */
    for($i=0;$i<$totalSheet;$i++){


      $Reader->ChangeSheet($i);


      foreach ($Reader as $Row)
      {
       
        
      	 
      	
      	 $query = "INSERT INTO `tbl_mcqs`(`sub_category_id`, `mcqs_question_type`, `mcqs_question`, `mcqs_options_type`, `mcqs_option_1`, `mcqs_option_2`, `mcqs_option_3`, `mcqs_option_4`, `mcqs_answer`, `mcqs_creator`) VALUES ($Row[0],'text','$Row[1]','text','$Row[2]','$Row[3]','$Row[4]','$Row[5]','$Row[6]',1)";
        

          $result = mysqli_query($con,$query);
      
          


        //$mysqli->query($query);
       }


    }


    



  }else { 
    die("<br/>Sorry, File type is not allowed. Only Excel file."); 
  }


}


?>