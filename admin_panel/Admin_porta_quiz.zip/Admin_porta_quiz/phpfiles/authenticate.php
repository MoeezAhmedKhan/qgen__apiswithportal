<?php

include_once('../assets/connection.php');
if(isset($_POST['submitLogin'])){
    session_start();
     $username = $_POST['username'];
     $password = $_POST['password'];

    $sql = "SELECT `user_id`, `user_name`, `profilepic`, `user_email`, `user_phone`, `user_password`, `user_status`, `user_type`, `user_created_date` FROM `tbl_users` WHERE `user_name`='$username' AND `user_password` = '$password' OR `user_email`='$username' AND `user_password` = '$password'";
    $result= mysqli_query($con,$sql);
    if($result){
             $Data = mysqli_fetch_array($result);
             $userid = $Data['user_id'];
             $user_type = $Data['user_type'];
             $_SESSION['userID'] = $userid;
             $_SESSION['user_type'] = $user_type;
             echo "<script>alert($userid)</script>";
             header('location:../index.php');
    }else{
       echo "<script>alert('username or passsword may be incorrect!')</script>";
    }
    
}


?>