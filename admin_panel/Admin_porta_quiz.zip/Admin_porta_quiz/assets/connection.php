<?php
$con =mysqli_connect("localhost","root","","db_quizapp");
if(!$con){
    echo "not connected";
}
?>