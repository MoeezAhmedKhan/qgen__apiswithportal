<?php
$username = 'User Name';
include('connection.php');
session_start();
if(isset($_SESSION['userID'])){
    $userid = $_SESSION['userID'];
    $profileLink = '';
    $sql = "SELECT `user_id`, `user_name`, `user_email`, `profilepic`  ,`user_phone`, `user_password`, `user_status`, `user_type`, `user_created_date` FROM `tbl_users` WHERE `user_id` = $userid";
    $result = mysqli_query($con,$sql);
    while($row= mysqli_fetch_array($result)){
        $username = $row['user_name'];
        $profileLink = $row['profilepic'];
        //echo "<script>alert('$profileLink')</script>";
    }

}else{
    header("location:./auth-login.php");
}
?>

<html>
    <head>

    </head>
    <body>
        <nav class="header-navbar navbar-expand-lg navbar navbar-with-menu floating-nav navbar-light navbar-shadow">
      <div class="navbar-wrapper">
        <div class="navbar-container content">
          <div class="navbar-collapse" id="navbar-mobile">
            <div class="mr-auto float-left bookmark-wrapper d-flex align-items-center">
             
              
             
             
            </div>
            <ul class="nav navbar-nav float-right">
              
              <li class="nav-item d-none d-lg-block"><a class="nav-link nav-link-expand"><i class="ficon feather icon-maximize"></i></a></li>
             
              </li>
              <li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                  <div class="user-nav d-sm-flex d-none"><span class="user-name text-bold-600"><?php echo "$username";  ?></span><span class="user-status">Available</span></div><span><img class="round" src="<?php echo $profileLink?>" alt="avatar" height="40" width="40"></span></a>
                <div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item" href="logout.php"></i> Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    </body>
</html>